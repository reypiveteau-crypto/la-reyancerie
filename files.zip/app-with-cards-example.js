/**
 * La Reyancerie - app.js (version avec fiches intégrées)
 * 
 * Exemple complet d'intégration des fiches HTML générées
 * Copie/adapte ce code à ton app.js existant
 */

// État global
let currentCharacterId = null;
let isLoading = false;

/**
 * Affiche la fiche d'un personnage
 */
async function showCharacter(characterId) {
  if (isLoading) return;
  isLoading = true;
  
  try {
    // Masque la liste/galerie
    const appDiv = document.getElementById('app');
    if (appDiv) appDiv.style.display = 'none';
    
    // Affiche le conteneur de fiche
    const cardContainer = document.getElementById('character-card-container');
    if (cardContainer) {
      cardContainer.style.display = 'block';
    }
    
    // Charge la fiche avec transition
    if (currentCharacterId && currentCharacterId !== characterId) {
      await CharacterCardLoader.transition(characterId, 'character-card-container');
    } else {
      await CharacterCardLoader.load(characterId, 'character-card-container');
    }
    
    currentCharacterId = characterId;
    
    // Scroll vers le haut de la fiche
    document.getElementById('character-card-container').scrollIntoView({ 
      behavior: 'smooth',
      block: 'start'
    });
    
    // Met à jour l'URL
    window.history.replaceState(null, '', `#${characterId}`);
    
  } catch (error) {
    console.error('Erreur lors de l\'affichage du personnage:', error);
  } finally {
    isLoading = false;
  }
}

/**
 * Affiche la liste/grille des personnages
 */
function showCharacterList() {
  // Masque la fiche
  const cardContainer = document.getElementById('character-card-container');
  if (cardContainer) {
    cardContainer.style.display = 'none';
  }
  
  // Affiche la liste
  const appDiv = document.getElementById('app');
  if (!appDiv) return;
  
  appDiv.style.display = 'block';
  appDiv.innerHTML = `
    <section class="characters-section">
      <h1>La Reyancerie</h1>
      <p class="subtitle">Guide des builds Genshin Impact</p>
      
      <div class="search-container">
        <input 
          type="text" 
          id="search-input" 
          placeholder="Chercher un personnage..."
          class="search-input"
        />
        <select id="element-filter" class="element-filter">
          <option value="">Tous les éléments</option>
          <option value="Pyro">🔥 Pyro</option>
          <option value="Hydro">💧 Hydro</option>
          <option value="Electro">⚡ Electro</option>
          <option value="Cryo">❄️ Cryo</option>
          <option value="Anemo">🌪️ Anemo</option>
          <option value="Geo">🪨 Geo</option>
          <option value="Dendro">🌱 Dendro</option>
        </select>
      </div>
      
      <div id="characters-grid" class="characters-grid"></div>
    </section>
  `;
  
  // Génère la grille
  renderCharacterGrid();
  
  // Ajoute les listeners de recherche
  setupSearch();
  
  currentCharacterId = null;
}

/**
 * Affiche la grille des personnages
 */
function renderCharacterGrid(filter = {}) {
  const grid = document.getElementById('characters-grid');
  if (!grid) return;
  
  // Filtre les personnages
  let filtered = characters;
  
  if (filter.search) {
    const search = filter.search.toLowerCase();
    filtered = filtered.filter(c => 
      c.name.toLowerCase().includes(search)
    );
  }
  
  if (filter.element) {
    filtered = filtered.filter(c => c.element === filter.element);
  }
  
  // Génère le HTML
  grid.innerHTML = filtered
    .map(character => `
      <div 
        class="character-card-item" 
        onclick="showCharacter('${character.id}')"
        data-character-id="${character.id}"
      >
        <div class="card-preview">
          <div class="card-element" style="color: ${getElementColor(character.element)}">
            ${character.element}
          </div>
          <h3>${character.name}</h3>
          <div class="card-rarity">${'★'.repeat(character.rarity || 4)}</div>
          <p class="card-weapon">${character.weapon || 'N/A'}</p>
          <button class="card-button">Voir la fiche</button>
        </div>
      </div>
    `)
    .join('');
  
  // Affiche le message si aucun résultat
  if (filtered.length === 0) {
    grid.innerHTML = '<p style="grid-column: 1/-1; text-align: center; color: #999;">Aucun personnage trouvé</p>';
  }
}

/**
 * Setup les filtres de recherche
 */
function setupSearch() {
  const searchInput = document.getElementById('search-input');
  const elementFilter = document.getElementById('element-filter');
  
  if (searchInput) {
    searchInput.addEventListener('input', debounce(() => {
      updateGridFilter();
    }, 300));
  }
  
  if (elementFilter) {
    elementFilter.addEventListener('change', () => {
      updateGridFilter();
    });
  }
}

/**
 * Met à jour le filtre de la grille
 */
function updateGridFilter() {
  const search = document.getElementById('search-input')?.value || '';
  const element = document.getElementById('element-filter')?.value || '';
  
  renderCharacterGrid({ search, element });
}

/**
 * Retourne la couleur d'un élément
 */
function getElementColor(element) {
  const colors = {
    Pyro: '#FF6B3B',
    Hydro: '#3B9FE3',
    Electro: '#D86FDE',
    Cryo: '#5ED2E6',
    Anemo: '#7FD8BE',
    Geo: '#FFC552',
    Dendro: '#7FD83B'
  };
  return colors[element] || '#fff';
}

/**
 * Utilitaire: debounce
 */
function debounce(fn, delay) {
  let timeout;
  return function(...args) {
    clearTimeout(timeout);
    timeout = setTimeout(() => fn(...args), delay);
  };
}

/**
 * Gestion du routage par fragment
 */
function handleRoute() {
  const hash = window.location.hash.slice(1);
  
  if (hash && characters.find(c => c.id === hash)) {
    showCharacter(hash);
  } else {
    showCharacterList();
  }
}

/**
 * Écoute les changements de route
 */
window.addEventListener('hashchange', handleRoute);

/**
 * Initialisation au démarrage
 */
document.addEventListener('DOMContentLoaded', () => {
  // Affiche la liste
  showCharacterList();
  
  // Gère la route initiale
  handleRoute();
  
  // Précharge les 20 premiers personnages pour une navigation rapide
  const firstTwenty = characters.slice(0, 20).map(c => c.id);
  CharacterCardLoader.preloadBulk(firstTwenty).catch(err => {
    console.debug('Préchargement échoué (non bloquant)', err);
  });
  
  console.log('✅ La Reyancerie chargée');
});

/**
 * Écoute le chargement des fiches
 */
window.addEventListener('cardLoaded', (e) => {
  const characterId = e.detail.characterId;
  console.log(`📋 Fiche ${characterId} chargée`);
  
  // Ici tu peux ajouter du tracking, analytics, etc.
});

// Export pour modules ES6
if (typeof module !== 'undefined' && module.exports) {
  module.exports = { showCharacter, showCharacterList };
}
