# 🎯 Guide d'intégration des fiches HTML au site

Comment intégrer les fiches HTML générées à ton site La Reyancerie.

---

## 📋 Checklist d'intégration

- [ ] Copier `character-cards-loader.js` à la racine
- [ ] Copier `character-card-styles.css` à la racine
- [ ] Modifier `index.html` (ajouter le script + CSS)
- [ ] Modifier `app.js` (charger les fiches)
- [ ] Générer les fiches: `npm run generate`
- [ ] Tester sur le site

---

## 1️⃣ Modification de `index.html`

Ajoute le CSS et le script dans ta section `<head>`:

```html
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>La Reyancerie</title>
  
  <!-- ✨ AJOUTE CES DEUX LIGNES ✨ -->
  <link rel="stylesheet" href="./character-card-styles.css">
  <script src="./character-cards-loader.js"></script>
  
  <!-- Tes autres styles -->
  <link rel="stylesheet" href="./styles.css">
</head>
<body>
  <!-- Conteneur pour la fiche -->
  <div id="character-card-container" style="display: none;"></div>
  
  <!-- Ton contenu existant -->
  <div id="app"></div>
  
  <script src="./app.js"></script>
</body>
</html>
```

---

## 2️⃣ Modification de `app.js`

### Scénario A: Si tu affiches déjà un personnage

Dans ta fonction qui affiche un personnage (par ex `showCharacter()`), remplace:

```javascript
// ❌ AVANT (affichage classique)
function showCharacter(characterId) {
  const character = characters.find(c => c.id === characterId);
  document.getElementById('app').innerHTML = \`
    <h1>\${character.name}</h1>
    <p>\${character.element}</p>
    <!-- ... ton affichage actuel ... -->
  \`;
}

// ✅ APRÈS (avec fiche généée)
function showCharacter(characterId) {
  const character = characters.find(c => c.id === characterId);
  
  // Option 1: Affiche JUSTE la fiche généée
  CharacterCardLoader.load(characterId);
  document.getElementById('character-card-container').style.display = 'block';
  document.getElementById('app').innerHTML = ''; // Cache l'ancien affichage
  
  // Option 2: Affiche fiche + contenu classique (voir plus bas)
}
```

### Scénario B: Afficher fiche + infos supplémentaires

```javascript
function showCharacter(characterId) {
  const character = characters.find(c => c.id === characterId);
  
  // Affiche la fiche générée
  CharacterCardLoader.load(characterId);
  
  // Affiche du contenu supplémentaire sous la fiche
  document.getElementById('app').innerHTML = \`
    <section class="character-details">
      <h2>À propos de \${character.name}</h2>
      <p>\${character.bio || 'Biographie non disponible'}</p>
      
      <h3>Conseils de build</h3>
      <p>Contenu personnalisé, guides, etc.</p>
    </section>
  \`;
  
  // Affiche le conteneur de fiche
  document.getElementById('character-card-container').style.display = 'block';
}
```

### Scénario C: Navigation avec transitions fluides

```javascript
function showCharacter(characterId) {
  // Transition fluide vers la nouvelle fiche
  CharacterCardLoader.transition(characterId);
  
  // Met à jour l'URL
  history.pushState(null, '', \`#\${characterId}\`);
}

// Lors du clic sur un personnage
document.addEventListener('click', (e) => {
  if (e.target.classList.contains('character-link')) {
    const id = e.target.dataset.characterId;
    showCharacter(id);
  }
});

// HTML des liens
\`<a href="#\${char.id}" class="character-link" data-character-id="\${char.id}">\${char.name}</a>\`
```

---

## 3️⃣ Intégration avec ton routage existant

Si tu utilises un routeur par fragment (`/#/albedo`):

```javascript
// Dans ton app.js, quand tu traites les routes:

const currentRoute = window.location.hash.slice(2); // Enlève #/
const characterId = currentRoute.split('/')[0];

if (characterId && characters.find(c => c.id === characterId)) {
  // Affiche la fiche du personnage
  showCharacter(characterId);
} else {
  // Affiche la liste des personnages
  showCharacterList();
}

// Écoute les changements de route
window.addEventListener('hashchange', () => {
  const newCharacterId = window.location.hash.slice(2).split('/')[0];
  if (newCharacterId) {
    showCharacter(newCharacterId);
  }
});
```

---

## 4️⃣ Personnalisation du chargement

### Afficher une fiche en mode compact

```javascript
// Pour afficher plusieurs fiches dans une grille, ajoute la classe 'compact'
async function loadCharacterPreview(characterId) {
  const container = document.createElement('div');
  
  try {
    const response = await fetch(\`./character-cards/\${characterId}.html\`);
    const html = await response.text();
    
    // Ajoute la classe 'compact'
    const modified = html.replace(
      'class="card"',
      'class="card compact"'
    );
    
    container.innerHTML = modified;
  } catch (error) {
    console.error('Erreur:', error);
  }
  
  return container.firstElementChild;
}
```

### Afficher plusieurs fiches dans une galerie

```javascript
async function showCharacterGallery(characterIds) {
  const gallery = document.getElementById('character-gallery');
  gallery.innerHTML = '';
  
  for (const id of characterIds) {
    const card = await loadCharacterPreview(id);
    gallery.appendChild(card);
  }
}

// Utilisation
showCharacterGallery(['albedo', 'amber', 'barbara']);
```

---

## 5️⃣ Options avancées

### Précharger les fiches pour une navigation rapide

```javascript
// Au démarrage, précharge les 10 premiers personnages
window.addEventListener('load', () => {
  const firstTen = characters.slice(0, 10).map(c => c.id);
  CharacterCardLoader.preloadBulk(firstTen);
});
```

### Écouter quand une fiche est chargée

```javascript
window.addEventListener('cardLoaded', (e) => {
  const characterId = e.detail.characterId;
  console.log(\`Fiche \${characterId} chargée\`);
  
  // Scroll vers la fiche
  document.getElementById('character-card-container').scrollIntoView({ 
    behavior: 'smooth' 
  });
});
```

### Modifier le conteneur par défaut

```javascript
// Si tu veux utiliser un conteneur différent
CharacterCardLoader.load('albedo', 'mon-conteneur-personnalisé');

// HTML
<div id="mon-conteneur-personnalisé"></div>
```

---

## 6️⃣ Structure finale du dépôt

```
la-reyancerie/
├── index.html                  ← Modifié ✏️
├── app.js                      ← Modifié ✏️
├── styles.css                  ← Existant
├── data.js                      ← Existant
├── fiche-generator.js           ← Générateur
├── character-cards-loader.js    ← Nouveau (loader)
├── character-card-styles.css    ← Nouveau (styles)
├── character-cards/             ← Généré automatiquement
│   ├── albedo.html             ← Fiche HTML
│   ├── albedo.png              ← Fiche PNG (partage)
│   ├── amber.html
│   ├── amber.png
│   └── ... (119 fichiers)
└── package.json
```

---

## 7️⃣ Génération et déploiement

### Générer les fiches

```bash
npm run generate
```

Cela crée:
- `character-cards/*.html` (fiches pour le site)
- `character-cards/*.png` (images pour partage réseaux sociaux)

### Committer les HTML

```bash
git add character-cards/*.html
git commit -m "Update character cards"
git push
```

**Note:** Les PNG occupent ~50MB, tu peux les exclure de git si tu veux:

```bash
echo "character-cards/*.png" >> .gitignore
git rm --cached character-cards/*.png
git commit -m "Exclude PNG from tracking"
```

---

## 🎨 Exemples de structure dans `app.js`

### Exemple complet minimaliste

```javascript
// data.js charge les 119 caractères dans 'characters'

// Conteneur actif
let currentCharacterId = null;

// Affiche un personnage
async function showCharacter(id) {
  currentCharacterId = id;
  document.getElementById('character-card-container').style.display = 'block';
  await CharacterCardLoader.load(id);
  
  // Met à jour l'URL
  window.history.replaceState(null, '', \`#\${id}\`);
}

// Liste des personnages (grille)
function showCharacterList() {
  document.getElementById('character-card-container').style.display = 'none';
  
  const grid = document.getElementById('app');
  grid.innerHTML = characters
    .map(char => \`
      <div class="character-card-preview">
        <h3>\${char.name}</h3>
        <p>\${char.element}</p>
        <button onclick="showCharacter('\${char.id}')">Voir la fiche</button>
      </div>
    \`)
    .join('');
}

// Route au démarrage
window.addEventListener('hashchange', () => {
  const id = window.location.hash.slice(1);
  if (characters.find(c => c.id === id)) {
    showCharacter(id);
  }
});

// Affiche la liste au chargement
showCharacterList();
```

---

## 🐛 Troubleshooting

### Les fiches ne s'affichent pas

1. Vérifie que `character-cards-loader.js` est chargé dans la console
2. Vérifie que les fichiers HTML existent: `npm run generate`
3. Vérifie l'URL: doit être `/character-cards/<id>.html` (chemin relatif)

### Les styles ne s'appliquent pas

1. Vérifie que `character-card-styles.css` est importé dans `<head>`
2. Nettoie le cache du navigateur (Ctrl+F5)
3. Ouvre la DevTools et cherche des erreurs CSS

### Les images de portraits ne s'affichent pas dans la fiche

1. Vérifie que les images sont nommées `<id>.png` à la racine
2. Relance `npm run generate` pour régénérer les fiches
3. Vérifie que base64 a bien encodé l'image (voir Console)

---

## 📞 Support

Besoin d'aide? Vérifie:
1. `character-cards-loader.js` chargé? → Ouvre DevTools, tape `CharacterCardLoader`
2. HTML généré? → `ls character-cards/` (doit avoir 119 fichiers)
3. Les chemins sont bons? → Vérifie la console (Network tab)

Bonne intégration! 🚀
